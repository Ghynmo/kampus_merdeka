import NameForm from "./Form/FormCoding";
import Search from "./Form/Search";

function App() {
  return (
    <>
      <NameForm />
      <Search />
    </>
  );
}

export default App;
